class IndonesiaModel {
  final int confirmed;
  final int recovered;
  final int deaths;
  final int activeCare;

  IndonesiaModel({this.confirmed, this.recovered, this.deaths, this.activeCare});
}