package com.example.uasprojek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
